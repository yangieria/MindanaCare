import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Appointments2 {

    private static final Color PRIMARY_BLUE = new Color(59, 130, 246);
    private static final Color LIGHT_BLUE_BG = new Color(224, 236, 252);
    private static final Color CALENDAR_TEXT = new Color(30, 58, 138);

    // Static variables to keep track of selection within the current session
    private static JButton selectedDayBtn = null;
    private static JButton selectedTimeBtn = null;

    public static JPanel createPanel() {
        // Main Background Panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(Color.WHITE);

        // Ensure the panel has a size for the JScrollPane in mindanaCare
        mainPanel.setPreferredSize(new Dimension(1100, 950));

        JPanel mainContainer = new JPanel();
        mainContainer.setLayout(new BoxLayout(mainContainer, BoxLayout.Y_AXIS));
        mainContainer.setBackground(Color.WHITE);

        JLabel header = new JLabel("<html><font color='#3b82f6'>Book</font> Appointment - <b>MINDANA</b><font color='#3b82f6'>CARE</font></html>");
        header.setFont(new Font("Segoe UI", Font.BOLD, 32));
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        header.setBorder(new EmptyBorder(30, 0, 20, 0));
        mainContainer.add(header);

        mainContainer.add(createStepper());
        mainContainer.add(Box.createRigidArea(new Dimension(0, 40)));

        JPanel calendarSection = new JPanel(new GridBagLayout());
        calendarSection.setBackground(LIGHT_BLUE_BG);
        calendarSection.setPreferredSize(new Dimension(1100, 600));
        calendarSection.add(createCalendarCard());

        mainContainer.add(calendarSection);

        // Wrap everything in a BorderLayout to push to the top
        mainPanel.add(mainContainer, BorderLayout.NORTH);

        return mainPanel;
    }

    private static JPanel createStepper() {
        RoundedPanel stepper = new RoundedPanel(10, new Color(200, 215, 240));
        stepper.setLayout(new GridLayout(1, 4));
        stepper.setMaximumSize(new Dimension(980, 55));
        stepper.setPreferredSize(new Dimension(980, 55));

        String[] steps = {"Select Doctor", "Confirm Doctor", "Confirm Details", "Confirm Appointment"};
        for (int i = 0; i < steps.length; i++) {
            JLabel s = new JLabel(steps[i], SwingConstants.CENTER);
            s.setFont(new Font("Segoe UI", Font.BOLD, 15));

            // Step 2 (Choose Details) is Active (Index 1)
            if(i == 1) {
                s.setOpaque(true);
                s.setBackground(PRIMARY_BLUE);
                s.setForeground(Color.WHITE);
            } else {
                s.setOpaque(false);
                s.setForeground(PRIMARY_BLUE);
            }
            stepper.add(s);
        }
        return stepper;
    }

    private static JPanel createCalendarCard() {
        RoundedPanel card = new RoundedPanel(40, Color.WHITE);
        card.setPreferredSize(new Dimension(550, 500));
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(25, 25, 25, 25));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel monthLabel = new JLabel("<html><font size='6' color='#1e3a8a'><b>January</b></font> <font size='6' color='#94a3b8'>2026</font></html>");
        JLabel subHeader = new JLabel("Thurs, Jan 22  🗓️ Schedule Now", SwingConstants.RIGHT);
        subHeader.setForeground(PRIMARY_BLUE);
        subHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        top.add(monthLabel, BorderLayout.WEST);
        top.add(subHeader, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);

        // --- CALENDAR GRID ---
        JPanel grid = new JPanel(new GridLayout(0, 7, 5, 5));
        grid.setOpaque(false);
        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String d : days) {
            grid.add(new JLabel(d, SwingConstants.CENTER));
        }

        for(int i=0; i<4; i++) grid.add(new JLabel(""));

        for (int i = 1; i <= 31; i++) {
            JButton dayBtn = new JButton(String.valueOf(i));
            dayBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
            dayBtn.setFocusPainted(false);
            dayBtn.setBorderPainted(false);
            dayBtn.setContentAreaFilled(false);
            dayBtn.setOpaque(false);
            dayBtn.setForeground(CALENDAR_TEXT);

            dayBtn.addActionListener(e -> {
                if (selectedDayBtn != null) {
                    selectedDayBtn.setOpaque(false);
                    selectedDayBtn.setForeground(CALENDAR_TEXT);
                }
                selectedDayBtn = dayBtn;
                selectedDayBtn.setOpaque(true);
                selectedDayBtn.setBackground(PRIMARY_BLUE);
                selectedDayBtn.setForeground(Color.WHITE);
                card.repaint();
            });

            if (i == 16) {
                Timer timer = new Timer(50, ev -> dayBtn.doClick());
                timer.setRepeats(false);
                timer.start();
            }
            grid.add(dayBtn);
        }
        centerPanel.add(grid, BorderLayout.CENTER);

        // --- TIME SLOTS ---
        JPanel timePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        timePanel.setOpaque(false);
        String[] times = {"09:00 AM", "10:30 AM", "1:30 PM", "3:30 PM", "4:30 PM"};

        for (String t : times) {
            JButton tBtn = new JButton(t);
            tBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
            tBtn.setPreferredSize(new Dimension(100, 40));

            // Check if slot is taken
            boolean taken = AppointmentManager.getInstance().isSlotTaken(
                    "Dr. Aria Pelobello",
                    String.valueOf(selectedDayBtn != null ? selectedDayBtn.getText() : ""),
                    t
            );

            if (taken) {
                tBtn.setBackground(new Color(220, 220, 220));
                tBtn.setForeground(Color.GRAY);
                tBtn.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true));
                tBtn.setEnabled(false);
                tBtn.setToolTipText("This slot is already booked");
            } else {
                tBtn.setBackground(Color.WHITE);
                tBtn.setForeground(CALENDAR_TEXT);
                tBtn.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true));
                tBtn.addActionListener(e -> {
                    if (selectedTimeBtn != null) {
                        selectedTimeBtn.setBackground(Color.WHITE);
                        selectedTimeBtn.setForeground(CALENDAR_TEXT);
                        selectedTimeBtn.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1, true));
                    }
                    selectedTimeBtn = tBtn;
                    selectedTimeBtn.setBackground(PRIMARY_BLUE);
                    selectedTimeBtn.setForeground(Color.WHITE);
                    selectedTimeBtn.setBorder(null);
                });
            }

            if (t.equals("1:30 PM") && !taken) {
                Timer timer = new Timer(50, ev -> tBtn.doClick());
                timer.setRepeats(false);
                timer.start();
            }
            timePanel.add(tBtn);
        }

        JButton nextBtn = new JButton("Confirm Selection & Continue >");
        nextBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
        nextBtn.setBackground(PRIMARY_BLUE);
        nextBtn.setForeground(Color.WHITE);
        nextBtn.setPreferredSize(new Dimension(0, 50));
        nextBtn.setOpaque(true);
        nextBtn.setBorderPainted(false);
        nextBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        nextBtn.addActionListener(e -> {
            if (selectedDayBtn == null) {
                JOptionPane.showMessageDialog(null, "Please select a date.", "Missing Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (selectedTimeBtn == null) {
                JOptionPane.showMessageDialog(null, "Please select a time slot.", "Missing Selection", JOptionPane.WARNING_MESSAGE);
                return;
            }
            AppointmentsMainPanel.setSelectedDate(selectedDayBtn.getText());
            AppointmentsMainPanel.setSelectedTime(selectedTimeBtn.getText());
            AppointmentsMainPanel.nextPage();
        });

        centerPanel.add(timePanel, BorderLayout.SOUTH);
        card.add(nextBtn, BorderLayout.SOUTH);
        card.add(centerPanel, BorderLayout.CENTER);

        return card;
    }

    // Custom Rounded Panel Class
    static class RoundedPanel extends JPanel {
        private int radius;
        private Color bgColor;
        public RoundedPanel(int radius, Color bgColor) {
            this.radius = radius;
            this.bgColor = bgColor;
            setOpaque(false);
        }
        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bgColor);
            g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), radius, radius));
            g2.dispose();
        }
    }
}