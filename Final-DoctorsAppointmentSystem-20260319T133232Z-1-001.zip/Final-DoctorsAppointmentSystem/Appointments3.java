import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.net.URL;

public class Appointments3 {

    private static final Color PRIMARY_BLUE = new Color(59, 130, 246);
    private static final Color GRADIENT_START = new Color(240, 247, 255);
    private static final Color GRADIENT_END = new Color(219, 234, 254);
    private static final Color TEXT_DARK = new Color(30, 41, 59);
    private static final Color TEXT_GRAY = new Color(100, 116, 139);
    private static final Color BORDER_COLOR = new Color(226, 232, 240);

    private static JTextField nameInput, idInput, emailInput, phoneInput;

    private static JPanel mainCardPanel;
    private static CardLayout cardLayout;

    public static JPanel createPanel() {
        // Main Content with Gradient Background
        JPanel mainContent = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, GRADIENT_START, 0, getHeight(), GRADIENT_END);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        mainContent.setLayout(new BorderLayout());
        // Set preferred size for JScrollPane compatibility
        mainContent.setPreferredSize(new Dimension(1100, 1000));

        JPanel wrapper = new JPanel();
        wrapper.setLayout(new BoxLayout(wrapper, BoxLayout.Y_AXIS));
        wrapper.setOpaque(false);
        wrapper.setBorder(new EmptyBorder(40, 60, 40, 60));

        JLabel header = new JLabel("<html><font color='#3b82f6'>Book</font> Appointment - <b>MINDANA</b><font color='#3b82f6'>CARE</font></html>");
        header.setFont(new Font("Segoe UI", Font.BOLD, 42));
        header.setAlignmentX(Component.CENTER_ALIGNMENT);
        wrapper.add(header);

        // ADDED: Global Stepper to match Appt 1 & 2
        wrapper.add(Box.createRigidArea(new Dimension(0, 30)));
        JPanel globalStepperContainer = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
        globalStepperContainer.setOpaque(false);
        globalStepperContainer.add(createGlobalStepper());
        wrapper.add(globalStepperContainer);

        wrapper.add(Box.createRigidArea(new Dimension(0, 50)));

        cardLayout = new CardLayout();
        mainCardPanel = new JPanel(cardLayout);
        mainCardPanel.setOpaque(false);

        // Add the steps
        mainCardPanel.add(createStepPanel("STEP 4 of 6", "Enter Your Information", 1, createInfoForm()), "STEP4");
        mainCardPanel.add(createStepPanel("STEP 5 of 6", "Reason for Consultation", 1, createReasonForm()), "STEP5");
        mainCardPanel.add(createStepPanel("STEP 6 of 6", "Confirm Your Appointment", 2, createConfirmSummary()), "STEP6");

        JPanel centerContainer = new JPanel(new GridBagLayout());
        centerContainer.setOpaque(false);
        centerContainer.add(mainCardPanel);

        wrapper.add(centerContainer);
        mainContent.add(wrapper, BorderLayout.NORTH);

        return mainContent;
    }

    // ADDED: The Global Stepper Method
    private static JPanel createGlobalStepper() {
        RoundedPanel stepper = new RoundedPanel(10, new Color(200, 215, 240));
        stepper.setLayout(new GridLayout(1, 4));
        stepper.setPreferredSize(new Dimension(980, 55));

        String[] steps = {"Select Doctor", "Confirm Doctor", "Confirm Details", "Confirm Appointment"};
        for (int i = 0; i < steps.length; i++) {
            JLabel s = new JLabel(steps[i], SwingConstants.CENTER);
            s.setFont(new Font("Segoe UI", Font.BOLD, 15));
            // Highlight index 2 because this is the 3rd step in the main process
            if(i == 2) {
                s.setOpaque(true);
                s.setBackground(PRIMARY_BLUE);
                s.setForeground(Color.WHITE);
            } else {
                s.setForeground(PRIMARY_BLUE);
                s.setOpaque(false);
            }
            stepper.add(s);
        }
        return stepper;
    }

    private static JPanel createStepPanel(String stepLabel, String title, int stepperIdx, JPanel content) {
        RoundedPanel card = new RoundedPanel(40, Color.WHITE);
        card.setPreferredSize(new Dimension(600, 850));
        card.setLayout(new BorderLayout());
        card.setBorder(new EmptyBorder(50, 45, 50, 45));

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel sLbl = new JLabel(stepLabel);
        sLbl.setFont(new Font("Segoe UI", Font.BOLD, 16));
        sLbl.setForeground(PRIMARY_BLUE);
        sLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tLbl = new JLabel(title);
        tLbl.setFont(new Font("Segoe UI", Font.BOLD, 32));
        tLbl.setForeground(TEXT_DARK);
        tLbl.setAlignmentX(Component.LEFT_ALIGNMENT);

        header.add(sLbl);
        header.add(Box.createRigidArea(new Dimension(0, 8)));
        header.add(tLbl);

        JPanel stepper = createRoundedStepper(stepperIdx);
        stepper.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel drCard = createDoctorCard();
        drCard.setAlignmentX(Component.LEFT_ALIGNMENT);

        header.add(Box.createRigidArea(new Dimension(0, 30)));
        header.add(stepper);
        header.add(Box.createRigidArea(new Dimension(0, 35)));
        header.add(drCard);
        header.add(Box.createRigidArea(new Dimension(0, 40)));

        card.add(header, BorderLayout.NORTH);
        card.add(content, BorderLayout.CENTER);

        JPanel footer = new JPanel(new GridLayout(1, 2, 25, 0));
        footer.setOpaque(false);
        footer.setBorder(new EmptyBorder(40, 0, 0, 0));

        JButton back = createStyledButton("< Back", false);
        JButton next = createStyledButton(stepperIdx == 2 ? "Confirm Appointment" : "Next Step >", true);

        back.addActionListener(e -> cardLayout.previous(mainCardPanel));
        next.addActionListener(e -> {
            if (next.getText().equals("Confirm Appointment")) {
                // Final confirmation step
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Confirm your appointment with Dr. Aria Pelobello\non January 22, 2026 at 1:30 PM?\n\nLocation: UM Health Center",
                        "Confirm Appointment", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (confirm == JOptionPane.YES_OPTION) {
                    User currentUser = UserManager.getInstance().getCurrentUser();
                    String date = AppointmentsMainPanel.getSelectedDate();
                    String time = AppointmentsMainPanel.getSelectedTime();
                    String specialty = AppointmentsMainPanel.getSelectedSpecialty().isEmpty()
                            ? "General" : AppointmentsMainPanel.getSelectedSpecialty();
                    String doctor = AppointmentsMainPanel.getSelectedDoctor().isEmpty()
                            ? "Dr. Aria Pelobello" : AppointmentsMainPanel.getSelectedDoctor();

                    if (AppointmentManager.getInstance().isSlotTaken(doctor, date, time)) {
                        JOptionPane.showMessageDialog(null,
                                "This time slot is already taken. Please choose another.",
                                "Slot Unavailable", JOptionPane.WARNING_MESSAGE);
                        return;
                    }

                    AppointmentManager.getInstance().book(
                            currentUser.getEmail(),
                            doctor,
                            specialty,
                            "January " + date + ", 2026",
                            time,
                            "UM Health Center"
                    );

                    JOptionPane.showMessageDialog(null,
                            "Appointment booked successfully!\nYou will receive a confirmation shortly.",
                            "Booking Confirmed", JOptionPane.INFORMATION_MESSAGE);
                    AppointmentsMainPanel.nextPage();
                }
            } else {
                // Validate info form before proceeding
                if (nameInput != null && nameInput.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Please fill in your full name.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (idInput != null && idInput.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Please fill in your ID number.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (emailInput != null && emailInput.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Please fill in your email address.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                if (phoneInput != null && phoneInput.getText().isBlank()) {
                    JOptionPane.showMessageDialog(null, "Please fill in your phone number.", "Missing Info", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                cardLayout.next(mainCardPanel);
            }
        });

        footer.add(back);
        footer.add(next);
        card.add(footer, BorderLayout.SOUTH);

        return card;
    }

    private static JPanel createInfoForm() {
        JPanel p = new JPanel(new GridLayout(8, 1, 0, 5));
        p.setOpaque(false);

        // Pre-fill from logged in user
        User currentUser = UserManager.getInstance().getCurrentUser();
        String prefillName  = currentUser != null ? currentUser.getFullName() : "";
        String prefillEmail = currentUser != null ? currentUser.getEmail() : "";
        String prefillPhone = currentUser != null ? currentUser.getContactNumber() : "";

        p.add(createGuideLabel("Full Name"));
        nameInput = createInput(prefillName);
        p.add(nameInput);

        p.add(createGuideLabel("ID Number"));
        idInput = createInput("");
        p.add(idInput);

        p.add(createGuideLabel("Email Address"));
        emailInput = createInput(prefillEmail);
        p.add(emailInput);

        p.add(createGuideLabel("Phone Number"));
        phoneInput = createInput(prefillPhone);
        p.add(phoneInput);

        return p;
    }

    private static JLabel createGuideLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 14));
        l.setForeground(TEXT_GRAY);
        return l;
    }

    private static JPanel createDoctorCard() {
        RoundedPanel p = new RoundedPanel(25, GRADIENT_START);
        p.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20));

        JPanel avatar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int diameter = Math.min(getWidth(), getHeight());
                Ellipse2D.Double circle = new Ellipse2D.Double(0, 0, diameter, diameter);
                g2.setClip(circle);
                URL imgURL = Appointments3.class.getResource("img.png");
                if (imgURL != null) {
                    Image img = new ImageIcon(imgURL).getImage();
                    g2.drawImage(img, 0, 0, diameter, diameter, null);
                } else {
                    g2.setColor(PRIMARY_BLUE);
                    g2.fill(circle);
                }
                g2.dispose();
            }
        };
        avatar.setPreferredSize(new Dimension(60, 60));
        avatar.setOpaque(false);

        JLabel info = new JLabel("<html><b style='font-size:12pt; color:#1e293b;'>"
                + AppointmentsMainPanel.getSelectedDoctor() + "</b><br>"
                + "<font color='gray'>" + AppointmentsMainPanel.getSelectedSpecialty() + "</font></html>");

        p.add(avatar);
        p.add(info);
        return p;
    }

    private static JPanel createRoundedStepper(int activeIdx) {
        JPanel ms = new JPanel(new GridLayout(1, 3, 15, 0));
        ms.setOpaque(false);
        ms.setMaximumSize(new Dimension(500, 45));
        String[] labels = {"1. Select", "2. Details", "3. Confirm"};
        for(int i=0; i<3; i++) {
            RoundedPanel box = new RoundedPanel(20, i <= activeIdx ? PRIMARY_BLUE : BORDER_COLOR);
            box.setLayout(new GridBagLayout());
            JLabel l = new JLabel(labels[i]);
            l.setFont(new Font("Segoe UI", Font.BOLD, 14));
            l.setForeground(i <= activeIdx ? Color.WHITE : Color.GRAY);
            l.setHorizontalAlignment(SwingConstants.CENTER);
            box.add(l);
            ms.add(box);
        }
        return ms;
    }

    private static JPanel createReasonForm() {
        JPanel p = new JPanel(new BorderLayout(0, 15));
        p.setOpaque(false);
        JTextArea area = new JTextArea("Experiencing chest pain and palpitations.");
        area.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        area.setLineWrap(true);
        area.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1), new EmptyBorder(20, 20, 20, 20)));
        p.add(new JLabel("Describe your concern:"), BorderLayout.NORTH);
        p.add(new JScrollPane(area), BorderLayout.CENTER);
        return p;
    }

    private static JPanel createConfirmSummary() {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        RoundedPanel box = new RoundedPanel(25, GRADIENT_START);
        box.setLayout(new BorderLayout());

        JLabel infoLabel = new JLabel();
        infoLabel.setVerticalAlignment(SwingConstants.TOP);

        p.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent e) {
                String date = AppointmentsMainPanel.getSelectedDate();
                String time = AppointmentsMainPanel.getSelectedTime();
                String specialty = AppointmentsMainPanel.getSelectedSpecialty().isEmpty()
                        ? "General" : AppointmentsMainPanel.getSelectedSpecialty();
                String doctor = AppointmentsMainPanel.getSelectedDoctor().isEmpty()
                        ? "Dr. Aria Pelobello" : AppointmentsMainPanel.getSelectedDoctor();

                infoLabel.setText("<html><body style='padding:30px; font-family:Segoe UI; font-size:14pt;'>"
                        + "<b>" + doctor + "</b><br>"
                        + "<font color='gray'>" + specialty + "</font><br><br>"
                        + "📅 <b>January " + date + ", 2026</b><br>"
                        + "🕒 <b>" + time + "</b><br><br>"
                        + "📍 <b>UM Health Center</b><br>"
                        + "<font color='gray'>University of Mindanao</font>"
                        + "</body></html>");
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent e) {}
            public void ancestorMoved(javax.swing.event.AncestorEvent e) {}
        });

        box.add(infoLabel);
        p.add(box, BorderLayout.NORTH);
        return p;
    }

    private static JTextField createInput(String val) {
        JTextField f = new JTextField(val);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_COLOR, 1), new EmptyBorder(12, 15, 12, 15)));
        return f;
    }

    private static JButton createStyledButton(String text, boolean primary) {
        JButton b = new JButton(text);
        b.setFont(new Font("Segoe UI", Font.BOLD, 16));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(200, 55));
        if (primary) {
            b.setBackground(PRIMARY_BLUE);
            b.setForeground(Color.WHITE);
            b.setBorder(null);
        } else {
            b.setBackground(Color.WHITE);
            b.setForeground(Color.GRAY);
            b.setBorder(BorderFactory.createLineBorder(BORDER_COLOR, 1));
        }
        return b;
    }

    static class RoundedPanel extends JPanel {
        private int r; private Color c;
        public RoundedPanel(int r, Color c) { this.r = r; this.c = c; setOpaque(false); }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(c); g2.fill(new RoundRectangle2D.Double(0,0,getWidth(),getHeight(),r,r));
            g2.dispose();
        }
    }
}